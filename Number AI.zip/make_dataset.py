import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.datasets import mnist

def augment_batch(images, labels, per_image=2):
    x = images.astype(np.float32) / 255.0
    x = np.expand_dims(x, -1)
    y = labels.astype(np.int64)

    aug = tf.keras.Sequential([
        tf.keras.layers.RandomRotation(0.12),
        tf.keras.layers.RandomTranslation(0.12, 0.12),
        tf.keras.layers.RandomZoom(0.15),
        tf.keras.layers.RandomContrast(0.2),
    ])

    xs = [x]
    ys = [y]
    for _ in range(per_image):
        xa = aug(x, training=True).numpy()
        xs.append(xa)
        ys.append(y)

    X = np.concatenate(xs, axis=0)
    Y = np.concatenate(ys, axis=0)

    idx = np.random.permutation(len(X))
    X = X[idx]
    Y = Y[idx]

    X = X.reshape(-1, 28, 28).astype(np.float32)
    return X, Y

def split_dataset(X, y, val_ratio=0.1, test_ratio=0.1):
    n = len(X)
    n_test = int(n * test_ratio)
    n_val = int(n * val_ratio)
    X_test, y_test = X[:n_test], y[:n_test]
    X_val, y_val = X[n_test:n_test + n_val], y[n_test:n_test + n_val]
    X_train, y_train = X[n_test + n_val:], y[n_test + n_val:]
    return (X_train, y_train), (X_val, y_val), (X_test, y_test)

def main():
    os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
    (x_train, y_train), (x_test, y_test) = mnist.load_data()
    X = np.concatenate([x_train, x_test], axis=0)
    y = np.concatenate([y_train, y_test], axis=0)

    X_aug, y_aug = augment_batch(X, y, per_image=2)
    (Xtr, ytr), (Xva, yva), (Xte, yte) = split_dataset(X_aug, y_aug, val_ratio=0.1, test_ratio=0.1)

    np.savez_compressed(
        "dataset.npz",
        X_train=Xtr, y_train=ytr,
        X_val=Xva, y_val=yva,
        X_test=Xte, y_test=yte
    )

    print("Saved dataset.npz")
    print("Train:", Xtr.shape, ytr.shape)
    print("Val  :", Xva.shape, yva.shape)
    print("Test :", Xte.shape, yte.shape)

if __name__ == "__main__":
    main()
