import os
import numpy as np
import tkinter as tk
from PIL import Image, ImageDraw, ImageOps
import tensorflow as tf

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Number AI")

        self.size = 280
        self.brush = 18

        self.canvas = tk.Canvas(root, width=self.size, height=self.size, bg="black", cursor="cross")
        self.canvas.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

        self.image = Image.new("L", (self.size, self.size), 0)
        self.draw = ImageDraw.Draw(self.image)

        self.canvas.bind("<B1-Motion>", self.paint)
        self.canvas.bind("<Button-1>", self.paint)

        self.label = tk.Label(root, text="Draw a digit and press Predict", font=("Arial", 14))
        self.label.grid(row=1, column=0, columnspan=4, pady=(0, 10))

        self.btn_predict = tk.Button(root, text="Predict", width=12, command=self.predict)
        self.btn_predict.grid(row=2, column=0, padx=5, pady=5)

        self.btn_clear = tk.Button(root, text="Clear", width=12, command=self.clear)
        self.btn_clear.grid(row=2, column=1, padx=5, pady=5)

        self.btn_save = tk.Button(root, text="Save PNG", width=12, command=self.save_png)
        self.btn_save.grid(row=2, column=2, padx=5, pady=5)

        self.btn_exit = tk.Button(root, text="Exit", width=12, command=root.quit)
        self.btn_exit.grid(row=2, column=3, padx=5, pady=5)

        if not os.path.exists("digit_model.keras"):
            self.model = None
            self.label.config(text="digit_model.keras not found. Run train_model.py first.")
        else:
            self.model = tf.keras.models.load_model("digit_model.keras")

    def paint(self, event):
        x1, y1 = (event.x - self.brush), (event.y - self.brush)
        x2, y2 = (event.x + self.brush), (event.y + self.brush)
        self.canvas.create_oval(x1, y1, x2, y2, fill="white", outline="white")
        self.draw.ellipse([x1, y1, x2, y2], fill=255)

    def clear(self):
        self.canvas.delete("all")
        self.image = Image.new("L", (self.size, self.size), 0)
        self.draw = ImageDraw.Draw(self.image)
        self.label.config(text="Draw a digit and press Predict")

    def preprocess(self):
        img = self.image.copy()
        bbox = img.getbbox()
        if bbox is None:
            return None
        img = img.crop(bbox)
        img = ImageOps.invert(img)
        img = ImageOps.autocontrast(img)
        img = ImageOps.invert(img)

        w, h = img.size
        scale = 20.0 / max(w, h)
        nw, nh = max(1, int(w * scale)), max(1, int(h * scale))
        img = img.resize((nw, nh), Image.Resampling.LANCZOS)

        canvas = Image.new("L", (28, 28), 0)
        ox = (28 - nw) // 2
        oy = (28 - nh) // 2
        canvas.paste(img, (ox, oy))

        arr = np.array(canvas).astype(np.float32) / 255.0
        arr = arr.reshape(1, 28, 28, 1)
        return arr

    def predict(self):
        if self.model is None:
            self.label.config(text="Model not loaded")
            return
        x = self.preprocess()
        if x is None:
            self.label.config(text="Nothing was drawn")
            return
        p = self.model.predict(x, verbose=0)[0]
        digit = int(np.argmax(p))
        conf = float(np.max(p))
        self.label.config(text=f"Result: {digit}   Confidence: {conf:.3f}")

    def save_png(self):
        self.image.save("draw.png")

def main():
    root = tk.Tk()
    App(root)
    root.mainloop()

if __name__ == "__main__":
    main()
