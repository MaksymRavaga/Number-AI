import os
import numpy as np
import tensorflow as tf

def load_data(path="dataset.npz"):
    data = np.load(path)
    X_train = data["X_train"].astype(np.float32)
    y_train = data["y_train"].astype(np.int64)
    X_val = data["X_val"].astype(np.float32)
    y_val = data["y_val"].astype(np.int64)
    X_test = data["X_test"].astype(np.float32)
    y_test = data["y_test"].astype(np.int64)

    X_train = X_train[..., None]
    X_val = X_val[..., None]
    X_test = X_test[..., None]
    return (X_train, y_train), (X_val, y_val), (X_test, y_test)

def build_model():
    inputs = tf.keras.Input(shape=(28, 28, 1))
    x = tf.keras.layers.Conv2D(32, 3, padding="same", activation="relu")(inputs)
    x = tf.keras.layers.Conv2D(32, 3, padding="same", activation="relu")(x)
    x = tf.keras.layers.MaxPool2D()(x)
    x = tf.keras.layers.Dropout(0.2)(x)

    x = tf.keras.layers.Conv2D(64, 3, padding="same", activation="relu")(x)
    x = tf.keras.layers.Conv2D(64, 3, padding="same", activation="relu")(x)
    x = tf.keras.layers.MaxPool2D()(x)
    x = tf.keras.layers.Dropout(0.25)(x)

    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dense(256, activation="relu")(x)
    x = tf.keras.layers.Dropout(0.35)(x)
    outputs = tf.keras.layers.Dense(10, activation="softmax")(x)

    model = tf.keras.Model(inputs, outputs)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"]
    )
    return model

def main():
    os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
    if not os.path.exists("dataset.npz"):
        raise FileNotFoundError("dataset.npz not found. Run make_dataset.py first.")

    (X_train, y_train), (X_val, y_val), (X_test, y_test) = load_data("dataset.npz")

    model = build_model()

    callbacks = [
        tf.keras.callbacks.ModelCheckpoint("digit_model.keras", monitor="val_accuracy", save_best_only=True, mode="max"),
        tf.keras.callbacks.EarlyStopping(monitor="val_accuracy", patience=5, restore_best_weights=True),
        tf.keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=2, min_lr=1e-5),
    ]

    model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=25,
        batch_size=256,
        callbacks=callbacks,
        verbose=2
    )

    test_loss, test_acc = model.evaluate(X_test, y_test, verbose=0)
    print("Test accuracy:", float(test_acc))

    model.save("digit_model.keras")
    print("Saved digit_model.keras")

if __name__ == "__main__":
    main()
